const games = [
    {
        name: "Eaglercraft",
        url: "books/mc.html",
        download: "books/mc.html"
    }
];